// ======= ON START =======
$(function () {

    inputListener();
    clickListener();
})

const inputListener = () => {
    $('input[id^=txt-]').change(function (e) {
        const id = e.target.id;
    });
}
const clickListener = () => {
    $('a[id^=btn-]').click(function (e) {
        const id = e.target.id;

        switch(id){
            case 'btn-check-email':
              
                $('#btn-check-email').addClass('loading');
                verifyEmail((success)=>{
                    $('#btn-check-email').removeClass('loading');
                });
                break;
        }
    });
}


// https://emailvalidation.abstractapi.com/v1/?api_key=2ef8421714614ceb9cc614189f67792b&email=csv121.a@gmail.com
const verifyEmail = (callback) =>{

    const emal = $('#txt-email').val();
    axios.get('https://emailvalidation.abstractapi.com/v1/',{
        params:{
            api_key:'2ef8421714614ceb9cc614189f67792b',
            email:emal
        }
    })
    .then(response =>{
        const data = response.data;
        let chip = '';
        chip += makeChip(data.is_valid_format ==true, "Valid", "Invalid");
        chip += makeChip(data.deliverability =="DELIVERABLE", "Active", "InActive");
        chip += makeChip(true,(data.quality_score*100) + "% rating",(data.quality_score*100) + "% rating");
        chip += makeChip(data.is_free_email.value == true, "Free Service","Paid Service");
        chip += makeChip(data.is_disposable_email.value != true, "Non Disposable","Disposable");
        chip += makeChip(data.is_mx_found.value ==  true, "Valid MX","Invalid MX");
        chip += makeChip(data.is_smtp_valid.value ==  true, "Valid SMTP","Invalid SMTP");

        $('#divider-lbl').attr('data-content', emal);
        $('#email-chips-area').html(chip);
        if(typeof callback == "function"){callback(true);}
    })
    .catch(error =>{
        console.log(error)
        if(typeof callback == "function"){callback(false);}
    })
}

const makeChip = (success=false, expected,unexpected)=>{

    return success?'<span class="chip bg-success">'+expected+'</span>':'<span class="chip bg-error">'+unexpected+'</span>';
}



