// ======= ON START =======
$(function () {
   fetchExchange('PHP', 'JPY,KWD,USD,AUD,SGD,HKD');
})


// JPY,KWD,PHP
const fetchExchange = (base, foreign) => {
    axios.get('https://api.apilayer.com/exchangerates_data/latest', {
        params: { base: base, symbols: foreign },
        headers: {'apiKey': '9Yj4xgNs7XtTaflvwS2dkNdz6WC2O1gp' },
    })
        .then(response => {
            const data = response.data;
            parseExchanges(data.rates);
            $('#exchange-date').text(data.date)

        })
        .catch(error => {
            console.log(error);
        });
}
const parseExchanges = (jsonRates) => {
    let tiles = '';
    Object.entries(jsonRates).forEach(([key, value]) => {
        console.log(`${key}: ${value}`)
        tiles += drawTile(key,value);
    });
    $('#exchange-area').html(tiles);
}

const drawTile = (symbol, value) => {
    const newVal = Math.round(((1/value) + Number.EPSILON) * 100) / 100;
    return '<div class="tile tile-centered p-2 mb-2 mt-2" ><div class="tile-icon"><div class="example-tile-icon"><i class="icon icon-file centered"></i></div></div><div class="tile-content"><div class="tile-title">'+symbol+'</div></div><div class="tile-action"><span>₱'+newVal+'</span></div></div>';
}